import { Phone, Mail } from 'lucide-react';
import { Button } from './Button';

interface AgentCardProps {
  name: string;
  role: string;
  image: string;
  phone: string;
  email: string;
  bio?: string;
  compact?: boolean;
}

export function AgentCard({ name, role, image, phone, email, bio, compact = false }: AgentCardProps) {
  if (compact) {
    return (
      <div className="bg-[#F6E9D7] rounded-xl p-6">
        <div className="flex items-center gap-4 mb-4">
          <img
            src={image}
            alt={name}
            className="w-16 h-16 rounded-full object-cover border-2 border-white"
          />
          <div>
            <h4 className="font-bold text-[#0B2545]">{name}</h4>
            <p className="text-sm text-[#6B7280]">{role}</p>
          </div>
        </div>
        <div className="space-y-2 mb-4">
          <a href={`tel:${phone}`} className="flex items-center gap-2 text-[#0B2545] hover:text-[#C75A3A] transition-colors">
            <Phone size={16} />
            <span className="text-sm">{phone}</span>
          </a>
          <a href={`mailto:${email}`} className="flex items-center gap-2 text-[#0B2545] hover:text-[#C75A3A] transition-colors">
            <Mail size={16} />
            <span className="text-sm">{email}</span>
          </a>
        </div>
        <Button variant="primary" className="w-full">Contact Agent</Button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow duration-200">
      <div className="h-64 overflow-hidden">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold text-[#0B2545] mb-1">{name}</h3>
        <p className="text-[#6B7280] mb-4">{role}</p>
        {bio && <p className="text-sm text-[#6B7280] mb-4 leading-relaxed">{bio}</p>}
        <div className="space-y-2 mb-4">
          <a href={`tel:${phone}`} className="flex items-center gap-2 text-[#0B2545] hover:text-[#C75A3A] transition-colors">
            <Phone size={18} />
            <span>{phone}</span>
          </a>
          <a href={`mailto:${email}`} className="flex items-center gap-2 text-[#0B2545] hover:text-[#C75A3A] transition-colors">
            <Mail size={18} />
            <span>{email}</span>
          </a>
        </div>
        <Button variant="primary" className="w-full">Contact Agent</Button>
      </div>
    </div>
  );
}
