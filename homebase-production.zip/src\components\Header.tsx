import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Menu, X, Phone } from 'lucide-react';
import { Link, useLocation } from 'react-router';
import { Button } from './Button';
import { CurrencyToggle } from './CurrencyToggle';

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Home', value: '' },
    { label: 'Listings', value: 'listings' },
    { label: 'Agents', value: 'agents' },
    { label: 'About', value: 'about' },
    { label: 'Blog', value: 'blog' },
    { label: 'Contact', value: 'contact' }
  ];

  return (
    <motion.header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md' : 'bg-white/95 backdrop-blur-sm'
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link
            to="/"
            className="text-2xl font-bold text-[#0B2545] tracking-tight hover:opacity-80 transition-opacity"
          >
            HomeBase <span className="text-[#C75A3A]">KE</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden xl:flex items-center gap-8">
            {navItems.map((item) => {
              const active = location.pathname === `/${item.value}`;
              return (
                <Link
                  key={item.value}
                  to={`/${item.value}`}
                  className={`${active ? 'text-[#C75A3A]' : 'text-[#0B2545]'} hover:text-[#C75A3A] transition-colors font-medium`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          {/* Desktop CTA */}
          <div className="hidden lg:flex items-center gap-4">
            <CurrencyToggle />
            <a href="tel:+254712345678" className="flex items-center gap-2 text-[#0B2545] hover:text-[#C75A3A] transition-colors">
              <Phone size={18} />
              <span className="font-medium">+254 712 345 678</span>
            </a>
            <Button variant="primary">Book Viewing</Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center gap-3">
            <CurrencyToggle className="hidden sm:flex" />
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-[#0B2545] p-2 hover:bg-[#F6E9D7] rounded-lg transition-colors"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <motion.nav
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden mt-4 pb-4 border-t border-[#F6E9D7] pt-4"
          >
            <div className="flex flex-col gap-4">
              {navItems.map((item) => (
                <Link
                  key={item.value}
                  to={`/${item.value}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-left text-[#0B2545] hover:text-[#C75A3A] transition-colors font-medium py-2"
                >
                  {item.label}
                </Link>
              ))}
              <div className="flex sm:hidden py-2 border-t border-[#F6E9D7]">
                <CurrencyToggle />
              </div>
              <div className="flex flex-col gap-3 pt-4 border-t border-[#F6E9D7]">
                <a href="tel:+254712345678" className="flex items-center gap-2 text-[#0B2545] font-medium">
                  <Phone size={18} />
                  <span>+254 712 345 678</span>
                </a>
                <Button variant="primary" className="w-full">Book Viewing</Button>
              </div>
            </div>
          </motion.nav>
        )}
      </div>
    </motion.header>
  );
}
