import { motion } from 'motion/react';
import { Bed, Bath, Maximize, MapPin } from 'lucide-react';
import { Badge } from './Badge';
import { useCurrency } from '../context/CurrencyContext';
import { formatPriceText } from '../utils/formatPrice';
import { WhatsAppButton } from './WhatsAppButton';

interface ListingCardProps {
  id: string;
  image: string;
  title: string;
  location: string;
  price: number | string;
  beds?: number;
  baths?: number;
  area: number | string;
  status?: string;
  type?: string;
  agentId?: string;
  agentPhone?: string;
  agentName?: string;
  onClick?: () => void;
  onOpenLeadModal?: () => void;
}

export function ListingCard({
  id,
  image,
  title,
  location,
  price,
  beds,
  baths,
  area,
  status = 'For Sale',
  type = 'property',
  agentPhone,
  agentName = 'Agent',
  onClick,
  onOpenLeadModal
}: ListingCardProps) {
  const { currency, kesToUsd } = useCurrency();

  const isContactForPrice = !price || price === 'Contact for price' || price === 0;
  
  let primaryPrice = 'Contact for price';
  let secondaryPrice = '';

  if (!isContactForPrice && typeof price === 'number') {
    const formatted = formatPriceText(price, currency, kesToUsd);
    primaryPrice = formatted.primary;
    secondaryPrice = formatted.secondary;
  } else if (!isContactForPrice && typeof price === 'string') {
    primaryPrice = price;
  }

  return (
    <motion.div
      className="group"
      whileHover={{ y: -8 }}
      transition={{ duration: 0.2 }}
    >
      <div className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-shadow duration-200">
        {/* Image */}
        <div className="relative h-64 overflow-hidden cursor-pointer" onClick={onClick}>
          <motion.img
            src={image}
            alt={title}
            className="w-full h-full object-cover"
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.3 }}
          />
          <div className="absolute top-4 left-4">
            <Badge variant="accent">{status.replace('_', ' ')}</Badge>
          </div>
          {type === 'land' && (
            <div className="absolute top-4 right-4">
              <Badge variant="default">Land</Badge>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="flex items-start justify-between mb-3 cursor-pointer" onClick={onClick}>
            <h3 className="text-xl font-bold text-[#0B2545] group-hover:text-[#C75A3A] transition-colors">
              {title}
            </h3>
          </div>

          <div className="flex items-center gap-2 text-[#6B7280] mb-4">
            <MapPin size={16} />
            <span className="text-sm">{location}</span>
          </div>

          <div className="flex items-center gap-4 mb-4 pb-4 border-b border-[#F6E9D7]">
            {type !== 'land' && beds !== undefined && (
              <div className="flex items-center gap-2 text-[#6B7280]">
                <Bed size={18} />
                <span className="text-sm">{beds} Beds</span>
              </div>
            )}
            {type !== 'land' && baths !== undefined && (
              <div className="flex items-center gap-2 text-[#6B7280]">
                <Bath size={18} />
                <span className="text-sm">{baths} Baths</span>
              </div>
            )}
            <div className="flex items-center gap-2 text-[#6B7280]">
              <Maximize size={18} />
              <span className="text-sm">{area} {type === 'land' ? 'acres' : 'sqm'}</span>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-[#C75A3A]">
                {primaryPrice}
              </div>
              {secondaryPrice && (
                <div className="text-xs text-[#6B7280] mt-1">
                  {secondaryPrice}
                </div>
              )}
            </div>
            
            <WhatsAppButton 
              phone={agentPhone} 
              agentName={agentName}
              listingId={id}
              listingTitle={title}
              onFallback={onOpenLeadModal}
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
}
