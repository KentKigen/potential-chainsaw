import { Award, Shield, Users, TrendingUp, Target, Heart } from 'lucide-react';
import { AgentCard } from '../components/AgentCard';
import { Button } from '../components/Button';

export function AboutPage() {
  const team = [
    {
      name: 'Grace Wanjiku',
      role: 'Senior Property Consultant',
      image: 'https://images.unsplash.com/photo-1667422234414-3cdcfc2bd883?w=400',
      phone: '+254 712 345 678',
      email: 'grace@homebaseke.com',
      bio: 'Specializes in residential properties across Ongata Rongai and greater Nairobi.'
    },
    {
      name: 'David Omondi',
      role: 'Property Consultant',
      image: 'https://images.unsplash.com/photo-1621973133111-63649acea55a?w=400',
      phone: '+254 722 456 789',
      email: 'david@homebaseke.com',
      bio: 'Expert in commercial and investment properties with 6 years experience.'
    },
    {
      name: 'Sarah Njeri',
      role: 'Rental Specialist',
      image: 'https://images.unsplash.com/photo-1667422234414-3cdcfc2bd883?w=400',
      phone: '+254 733 567 890',
      email: 'sarah@homebaseke.com',
      bio: 'Dedicated to helping clients find perfect rental homes and manage properties.'
    }
  ];

  const values = [
    {
      icon: Shield,
      title: 'Integrity',
      description: 'We maintain the highest ethical standards in all our transactions and relationships.'
    },
    {
      icon: Heart,
      title: 'Client-First',
      description: 'Your goals and satisfaction are at the heart of everything we do.'
    },
    {
      icon: Award,
      title: 'Excellence',
      description: 'We strive for excellence in service delivery and market expertise.'
    },
    {
      icon: Target,
      title: 'Transparency',
      description: 'Clear communication, verified listings, and no hidden fees ever.'
    }
  ];

  return (
    <div className="pt-24 min-h-screen bg-white">
      {/* Hero */}
      <section className="relative h-[500px] flex items-center">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1741991110666-88115e724741?w=1920"
            alt="Nairobi"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-[#0B2545]/80" />
        </div>

        <div className="relative max-w-7xl mx-auto px-6 text-white">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">About HomeBase KE</h1>
          <p className="text-xl max-w-2xl text-white/90">
            Your trusted partner in finding premium real estate across Ongata Rongai and greater Nairobi since 2015.
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-6">
          <h2 className="text-4xl font-bold text-[#0B2545] mb-6 text-center">Our Story</h2>
          <div className="space-y-4 text-lg text-[#6B7280] leading-relaxed">
            <p>
              Founded in 2015, HomeBase KE was born from a simple mission: to make quality real estate accessible and transparent for everyone in Nairobi. We saw a market filled with unverified listings, hidden fees, and agents who didn't truly understand local neighborhoods.
            </p>
            <p>
              Today, we're proud to be one of Ongata Rongai's most trusted real estate firms. Our team of dedicated professionals brings deep local market knowledge, ethical practices, and a genuine commitment to helping you find not just a property, but a home.
            </p>
            <p>
              With over 500 successful transactions and a 98% client satisfaction rate, we've built our reputation on integrity, transparency, and results. Every property in our portfolio is personally verified, every price is clear, and every client receives the attention they deserve.
            </p>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 bg-[#0B2545] text-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-5xl font-bold text-[#C75A3A] mb-2">500+</div>
              <div className="text-white/80">Properties Sold</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-[#C75A3A] mb-2">98%</div>
              <div className="text-white/80">Client Satisfaction</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-[#C75A3A] mb-2">10+</div>
              <div className="text-white/80">Years Experience</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-[#C75A3A] mb-2">15</div>
              <div className="text-white/80">Expert Agents</div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-[#F6E9D7]">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-4xl font-bold text-[#0B2545] mb-12 text-center">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value) => {
              const Icon = value.icon;
              return (
                <div key={value.title} className="text-center">
                  <div className="w-16 h-16 bg-[#C75A3A] rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="text-white" size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-[#0B2545] mb-2">{value.title}</h3>
                  <p className="text-[#6B7280]">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-4xl font-bold text-[#0B2545] mb-4 text-center">Meet Our Team</h2>
          <p className="text-lg text-[#6B7280] text-center mb-12">
            Experienced professionals dedicated to your real estate success
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {team.map((member) => (
              <AgentCard key={member.name} {...member} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-[#C75A3A]">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">Ready to Start Your Journey?</h2>
          <p className="text-xl text-white/90 mb-8">
            Whether you're buying, selling, or renting, we're here to help every step of the way.
          </p>
          <Button variant="secondary" className="text-lg px-12">
            Contact Us Today
          </Button>
        </div>
      </section>
    </div>
  );
}
