import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { FormField } from '../components/FormField';
import { Button } from '../components/Button';

export function ContactPage() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thank you for your message! We will get back to you within 24 hours.');
  };

  const offices = [
    {
      name: 'Ongata Rongai Office',
      address: 'Magadi Road, Ongata Rongai',
      city: 'Nairobi, Kenya',
      phone: '+254 712 345 678',
      email: 'rongai@homebaseke.com',
      hours: 'Mon-Fri: 8:00 AM - 6:00 PM\nSat: 9:00 AM - 4:00 PM\nSun: Closed'
    },
    {
      name: 'Nairobi CBD Office',
      address: 'Kimathi Street, 4th Floor',
      city: 'Nairobi, Kenya',
      phone: '+254 722 456 789',
      email: 'cbd@homebaseke.com',
      hours: 'Mon-Fri: 8:00 AM - 6:00 PM\nSat: 9:00 AM - 2:00 PM\nSun: Closed'
    }
  ];

  return (
    <div className="pt-24 min-h-screen bg-white">
      {/* Hero */}
      <section className="bg-[#0B2545] text-white py-16">
        <div className="max-w-7xl mx-auto px-6">
          <h1 className="text-5xl font-bold mb-4">Get in Touch</h1>
          <p className="text-xl text-white/80">
            We're here to help you find your perfect property
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div>
            <h2 className="text-3xl font-bold text-[#0B2545] mb-6">Send Us a Message</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <FormField
                  label="First Name"
                  type="text"
                  placeholder="John"
                  required
                />
                <FormField
                  label="Last Name"
                  type="text"
                  placeholder="Kamau"
                  required
                />
              </div>

              <FormField
                label="Email Address"
                type="email"
                placeholder="john@example.com"
                required
              />

              <FormField
                label="Phone Number"
                type="tel"
                placeholder="+254 712 345 678"
                required
              />

              <div>
                <label className="block text-[#0B2545] font-medium mb-2">
                  I'm interested in
                </label>
                <select className="w-full px-4 py-3 bg-[#F6E9D7] border border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C75A3A]">
                  <option>Buying a Property</option>
                  <option>Selling a Property</option>
                  <option>Renting a Property</option>
                  <option>Property Valuation</option>
                  <option>General Inquiry</option>
                </select>
              </div>

              <FormField
                label="Your Message"
                multiline
                placeholder="Tell us about your requirements..."
                required
              />

              <Button type="submit" variant="primary" className="w-full">
                Send Message
              </Button>

              <p className="text-sm text-[#6B7280] text-center">
                We typically respond within 24 hours
              </p>
            </form>
          </div>

          {/* Office Information */}
          <div>
            <h2 className="text-3xl font-bold text-[#0B2545] mb-6">Our Offices</h2>
            <div className="space-y-6">
              {offices.map((office) => (
                <div key={office.name} className="bg-[#F6E9D7] rounded-xl p-6">
                  <h3 className="text-xl font-bold text-[#0B2545] mb-4">{office.name}</h3>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 text-[#6B7280]">
                      <MapPin size={20} className="mt-1 flex-shrink-0 text-[#C75A3A]" />
                      <div>
                        <p>{office.address}</p>
                        <p>{office.city}</p>
                      </div>
                    </div>

                    <a
                      href={`tel:${office.phone}`}
                      className="flex items-center gap-3 text-[#6B7280] hover:text-[#C75A3A] transition-colors"
                    >
                      <Phone size={20} className="flex-shrink-0 text-[#C75A3A]" />
                      <span>{office.phone}</span>
                    </a>

                    <a
                      href={`mailto:${office.email}`}
                      className="flex items-center gap-3 text-[#6B7280] hover:text-[#C75A3A] transition-colors"
                    >
                      <Mail size={20} className="flex-shrink-0 text-[#C75A3A]" />
                      <span>{office.email}</span>
                    </a>

                    <div className="flex items-start gap-3 text-[#6B7280]">
                      <Clock size={20} className="mt-1 flex-shrink-0 text-[#C75A3A]" />
                      <div className="whitespace-pre-line">{office.hours}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Quick Contact */}
            <div className="mt-8 bg-[#C75A3A] text-white rounded-xl p-6">
              <h3 className="text-xl font-bold mb-3">Need Immediate Assistance?</h3>
              <p className="mb-4">Call our main office line for urgent inquiries</p>
              <a
                href="tel:+254712345678"
                className="text-2xl font-bold hover:underline"
              >
                +254 712 345 678
              </a>
            </div>
          </div>
        </div>

        {/* Map */}
        <div className="mt-16">
          <h2 className="text-3xl font-bold text-[#0B2545] mb-6 text-center">Find Us on the Map</h2>
          <div className="bg-[#F6E9D7] rounded-xl h-[400px] flex items-center justify-center">
            <div className="text-center text-[#6B7280]">
              <MapPin size={48} className="mx-auto mb-4" />
              <p>Interactive map would be integrated here</p>
              <p className="text-sm mt-2">(Google Maps or similar service)</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
