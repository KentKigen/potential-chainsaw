import { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Award, Shield, Users, ChevronLeft, ChevronRight } from 'lucide-react';
import { ListingCard } from '../components/ListingCard';
import { Button } from '../components/Button';
import { LeadModal } from '../components/LeadModal';

interface HomePageProps {
  onNavigate?: (page: string) => void;
  onPropertyClick?: (id: string) => void;
}

export function HomePage({ onNavigate, onPropertyClick }: HomePageProps) {
  const [isLeadFormOpen, setIsLeadFormOpen] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);

  const featuredProperties = [
    {
      id: '1',
      image: 'https://images.unsplash.com/photo-1658218635253-64728f6234be?w=800',
      title: 'Modern 3BR Villa',
      location: 'Ongata Rongai, Nairobi',
      price: 'KES 12.5M',
      beds: 3,
      baths: 2,
      area: '180 sqm',
      status: 'For Sale' as const
    },
    {
      id: '2',
      image: 'https://images.unsplash.com/photo-1658218729615-167c32d70537?w=800',
      title: 'Luxury 4BR Family Home',
      location: 'Karen, Nairobi',
      price: 'KES 25M',
      beds: 4,
      baths: 3,
      area: '280 sqm',
      status: 'For Sale' as const
    },
    {
      id: '3',
      image: 'https://images.unsplash.com/photo-1694465990855-e78110c345af?w=800',
      title: 'Contemporary 2BR Apartment',
      location: 'Kilimani, Nairobi',
      price: 'KES 95,000/mo',
      beds: 2,
      baths: 2,
      area: '120 sqm',
      status: 'For Rent' as const
    }
  ];

  const neighborhoods = [
    {
      name: 'Ongata Rongai',
      image: 'https://images.unsplash.com/photo-1741991110666-88115e724741?w=600',
      properties: '150+ Properties'
    },
    {
      name: 'Karen',
      image: 'https://images.unsplash.com/photo-1658218635253-64728f6234be?w=600',
      properties: '80+ Properties'
    },
    {
      name: 'Kilimani',
      image: 'https://images.unsplash.com/photo-1694465990855-e78110c345af?w=600',
      properties: '120+ Properties'
    }
  ];

  const testimonials = [
    {
      quote: "HomeBase made finding our dream home effortless. Professional service and verified listings gave us complete confidence.",
      author: "Sarah & James Mwangi",
      location: "Ongata Rongai"
    },
    {
      quote: "Transparent pricing, no hidden fees, and expert knowledge of the Nairobi market. Highly recommend!",
      author: "David Omondi",
      location: "Karen"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1741991110666-88115e724741?w=1920"
            alt="Nairobi Skyline"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0B2545]/90 to-[#0B2545]/60" />
        </div>

        {/* Content */}
        <div className="relative max-w-7xl mx-auto px-6 w-full">
          <div className="max-w-2xl">
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight"
            >
              Find Your Home in Nairobi
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-xl text-white/90 mb-8"
            >
              Verified listings. Local expertise. No hidden fees.
            </motion.p>

            {/* Search Bar */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="bg-white rounded-xl p-4 shadow-2xl flex flex-col md:flex-row gap-4"
            >
              <div className="flex-1 flex items-center gap-3 px-4 py-2 bg-[#F6E9D7] rounded-lg">
                <Search size={20} className="text-[#6B7280]" />
                <input
                  type="text"
                  placeholder="Search by location, property type..."
                  className="flex-1 bg-transparent outline-none text-[#0B2545] placeholder:text-[#6B7280]"
                />
              </div>
              <Button
                variant="primary"
                onClick={() => onNavigate?.('listings')}
                className="md:w-auto"
              >
                Search Properties
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Featured Listings */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-[#0B2545] mb-4">Featured Listings</h2>
            <p className="text-lg text-[#6B7280]">Handpicked properties from premium Nairobi neighborhoods</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProperties.map((property) => (
              <ListingCard
                key={property.id}
                {...property}
                onClick={() => onPropertyClick?.(property.id)}
              />
            ))}
          </div>

          <div className="text-center mt-12">
            <Button variant="outline" onClick={() => onNavigate?.('listings')}>
              View All Listings
            </Button>
          </div>
        </div>
      </section>

      {/* Neighborhoods */}
      <section className="py-20 bg-[#F6E9D7]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-[#0B2545] mb-4">Explore Neighborhoods</h2>
            <p className="text-lg text-[#6B7280]">Discover your ideal community in Nairobi</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {neighborhoods.map((neighborhood) => (
              <motion.div
                key={neighborhood.name}
                whileHover={{ y: -8 }}
                className="relative h-80 rounded-xl overflow-hidden group cursor-pointer shadow-lg"
              >
                <img
                  src={neighborhood.image}
                  alt={neighborhood.name}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B2545]/90 to-transparent flex flex-col justify-end p-6">
                  <h3 className="text-2xl font-bold text-white mb-2">{neighborhood.name}</h3>
                  <p className="text-white/80">{neighborhood.properties}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Bar */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-[#C75A3A] rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-bold text-[#0B2545] mb-2">Verified Listings</h3>
              <p className="text-[#6B7280]">Every property thoroughly verified for authenticity</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-[#C75A3A] rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-bold text-[#0B2545] mb-2">Award-Winning Service</h3>
              <p className="text-[#6B7280]">Recognized for excellence in Kenyan real estate</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-[#C75A3A] rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-bold text-[#0B2545] mb-2">Local Expertise</h3>
              <p className="text-[#6B7280]">Deep knowledge of Nairobi and Ongata Rongai markets</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-[#0B2545]">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-white mb-4">What Our Clients Say</h2>
          </div>

          <div className="relative">
            <motion.div
              key={currentSlide}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-white/10 backdrop-blur-sm rounded-xl p-8 md:p-12"
            >
              <p className="text-xl text-white/90 mb-6 leading-relaxed italic">
                "{testimonials[currentSlide].quote}"
              </p>
              <div className="text-white">
                <p className="font-bold">{testimonials[currentSlide].author}</p>
                <p className="text-white/70">{testimonials[currentSlide].location}</p>
              </div>
            </motion.div>

            <div className="flex items-center justify-center gap-4 mt-8">
              <button
                onClick={() => setCurrentSlide((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1))}
                className="p-2 bg-white/20 hover:bg-white/30 rounded-full transition-colors"
              >
                <ChevronLeft className="text-white" size={24} />
              </button>
              <div className="flex gap-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === currentSlide ? 'bg-white w-8' : 'bg-white/40'
                    }`}
                  />
                ))}
              </div>
              <button
                onClick={() => setCurrentSlide((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1))}
                className="p-2 bg-white/20 hover:bg-white/30 rounded-full transition-colors"
              >
                <ChevronRight className="text-white" size={24} />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#C75A3A]">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">Ready to Find Your Dream Home?</h2>
          <p className="text-xl text-white/90 mb-8">
            Book a viewing today and let our experts guide you through the perfect property.
          </p>
          <Button
            variant="secondary"
            onClick={() => setIsLeadFormOpen(true)}
            className="text-lg px-12"
          >
            Book a Viewing
          </Button>
        </div>
      </section>

      <LeadModal
        isOpen={isLeadFormOpen}
        onClose={() => setIsLeadFormOpen(false)}
      />
    </div>
  );
}
