import { useState } from 'react';
import { motion } from 'motion/react';
import { Bed, Bath, Maximize, MapPin, Download, ChevronLeft, ChevronRight, Calendar } from 'lucide-react';
import { Button } from '../components/Button';
import { Badge } from '../components/Badge';
import { AgentCard } from '../components/AgentCard';
import { LeadModal } from '../components/LeadModal';

export function ListingDetailPage() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isLeadFormOpen, setIsLeadFormOpen] = useState(false);

  const images = [
    'https://images.unsplash.com/photo-1658218635253-64728f6234be?w=1200',
    'https://images.unsplash.com/photo-1658218729615-167c32d70537?w=1200',
    'https://images.unsplash.com/photo-1694465990855-e78110c345af?w=1200',
    'https://images.unsplash.com/photo-1639220814863-7f1408750b57?w=1200'
  ];

  const property = {
    title: 'Modern 3BR Villa with Garden',
    location: 'Ongata Rongai, Nairobi',
    price: 'KES 12,500,000',
    status: 'For Sale',
    beds: 3,
    baths: 2,
    area: '180 sqm',
    description: 'This stunning modern villa offers contemporary living in the heart of Ongata Rongai. Featuring an open-plan layout with abundant natural light, high-end finishes throughout, and a private garden perfect for family gatherings. The property includes a spacious master suite with walk-in closet, modern kitchen with premium appliances, and secure parking for two vehicles.',
    features: [
      'Master en-suite with walk-in closet',
      'Modern fitted kitchen',
      'Spacious living and dining area',
      'Private garden',
      'Secure parking for 2 cars',
      'Backup water supply',
      'Solar water heating',
      'CCTV security system',
      'Perimeter wall with electric fence'
    ],
    propertyDetails: {
      'Property Type': 'Villa',
      'Year Built': '2023',
      'Plot Size': '1/4 Acre',
      'Title Deed': 'Ready',
      'Occupancy': 'Immediate',
      'Parking': '2 Spaces'
    }
  };

  const agent = {
    name: 'Grace Wanjiku',
    role: 'Senior Property Consultant',
    image: 'https://images.unsplash.com/photo-1667422234414-3cdcfc2bd883?w=400',
    phone: '+254 712 345 678',
    email: 'grace@homebaseke.com',
    bio: 'With over 8 years of experience in Nairobi real estate, Grace specializes in residential properties in Ongata Rongai and surrounding areas.'
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <div className="pt-24 min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Image Gallery */}
        <div className="mb-8">
          {/* Main Image */}
          <div className="relative h-[500px] rounded-xl overflow-hidden mb-4 group">
            <motion.img
              key={currentImageIndex}
              src={images[currentImageIndex]}
              alt={`Property image ${currentImageIndex + 1}`}
              className="w-full h-full object-cover"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
            />

            {/* Navigation Arrows */}
            <button
              onClick={prevImage}
              className="absolute left-4 top-1/2 -translate-y-1/2 p-3 bg-white/90 hover:bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <ChevronLeft size={24} className="text-[#0B2545]" />
            </button>
            <button
              onClick={nextImage}
              className="absolute right-4 top-1/2 -translate-y-1/2 p-3 bg-white/90 hover:bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <ChevronRight size={24} className="text-[#0B2545]" />
            </button>

            {/* Image Counter */}
            <div className="absolute bottom-4 right-4 px-4 py-2 bg-[#0B2545]/80 backdrop-blur-sm rounded-lg text-white">
              {currentImageIndex + 1} / {images.length}
            </div>

            {/* Status Badge */}
            <div className="absolute top-4 left-4">
              <Badge variant="accent">{property.status}</Badge>
            </div>
          </div>

          {/* Thumbnail Strip */}
          <div className="grid grid-cols-4 gap-4">
            {images.map((image, index) => (
              <button
                key={index}
                onClick={() => setCurrentImageIndex(index)}
                className={`h-24 rounded-lg overflow-hidden border-2 transition-all ${
                  index === currentImageIndex ? 'border-[#C75A3A]' : 'border-transparent hover:border-[#F6E9D7]'
                }`}
              >
                <img src={image} alt={`Thumbnail ${index + 1}`} className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Title & Price */}
            <div className="mb-6">
              <h1 className="text-4xl font-bold text-[#0B2545] mb-3">{property.title}</h1>
              <div className="flex items-center gap-2 text-[#6B7280] mb-4">
                <MapPin size={20} />
                <span className="text-lg">{property.location}</span>
              </div>
              <div className="text-4xl font-bold text-[#C75A3A]">{property.price}</div>
            </div>

            {/* Key Facts */}
            <div className="flex flex-wrap gap-6 mb-8 pb-8 border-b border-[#F6E9D7]">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-[#F6E9D7] rounded-lg flex items-center justify-center">
                  <Bed size={24} className="text-[#0B2545]" />
                </div>
                <div>
                  <p className="text-sm text-[#6B7280]">Bedrooms</p>
                  <p className="text-lg font-bold text-[#0B2545]">{property.beds}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-[#F6E9D7] rounded-lg flex items-center justify-center">
                  <Bath size={24} className="text-[#0B2545]" />
                </div>
                <div>
                  <p className="text-sm text-[#6B7280]">Bathrooms</p>
                  <p className="text-lg font-bold text-[#0B2545]">{property.baths}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-[#F6E9D7] rounded-lg flex items-center justify-center">
                  <Maximize size={24} className="text-[#0B2545]" />
                </div>
                <div>
                  <p className="text-sm text-[#6B7280]">Area</p>
                  <p className="text-lg font-bold text-[#0B2545]">{property.area}</p>
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-[#0B2545] mb-4">Description</h2>
              <p className="text-[#6B7280] leading-relaxed">{property.description}</p>
            </div>

            {/* Features */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-[#0B2545] mb-4">Features & Amenities</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {property.features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-[#C75A3A] rounded-full"></div>
                    <span className="text-[#6B7280]">{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Property Details */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-[#0B2545] mb-4">Property Details</h2>
              <div className="grid grid-cols-2 gap-4">
                {Object.entries(property.propertyDetails).map(([key, value]) => (
                  <div key={key} className="bg-[#F6E9D7] rounded-lg p-4">
                    <p className="text-sm text-[#6B7280] mb-1">{key}</p>
                    <p className="font-medium text-[#0B2545]">{value}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-28 space-y-6">
              {/* Action Buttons */}
              <div className="bg-[#F6E9D7] rounded-xl p-6 space-y-4">
                <Button
                  variant="primary"
                  className="w-full"
                  onClick={() => setIsLeadFormOpen(true)}
                >
                  <Calendar className="inline mr-2" size={20} />
                  Schedule Viewing
                </Button>
                <Button variant="outline" className="w-full">
                  <Download className="inline mr-2" size={20} />
                  Download Brochure
                </Button>
              </div>

              {/* Agent Card */}
              <AgentCard {...agent} compact />

              {/* Mortgage Calculator Placeholder */}
              <div className="bg-white border-2 border-[#F6E9D7] rounded-xl p-6">
                <h3 className="font-bold text-[#0B2545] mb-4">Mortgage Calculator</h3>
                <p className="text-sm text-[#6B7280] mb-4">
                  Calculate your monthly payments based on this property price.
                </p>
                <Button variant="outline" className="w-full">Calculate</Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <LeadModal
        isOpen={isLeadFormOpen}
        onClose={() => setIsLeadFormOpen(false)}
        propertyTitle={property.title}
      />
    </div>
  );
}
